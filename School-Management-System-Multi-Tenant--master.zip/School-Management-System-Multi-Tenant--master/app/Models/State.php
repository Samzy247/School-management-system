<?php

namespace App\Models;

use Eloquent;

class State extends Eloquent
{
    public function ministry()
    {
       // return $this->hasMany(Ministry::class);
    }
}
